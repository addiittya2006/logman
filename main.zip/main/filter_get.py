__author__ = 'gaurav'

fo=open("cleanlog", "w")
with open("logs") as logs:
    for line in logs:
        if "GET" in line or "POST" in line:
            newlist=line.split()
            # print newlist[4]
            fo.write(newlist[4]+" " + newlist[5]+ " " + newlist[-3][1:]+ " " + newlist[-2]+"\n")
fo.close()

